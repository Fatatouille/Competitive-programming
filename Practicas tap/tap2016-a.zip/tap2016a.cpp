#include <iostream>
#include <string>

using namespace std;

int main()
{
	string palabra;
	char salida;

	while(getline(cin, palabra) && !palabra.empty())
	{
		salida = 'S';
		for(int i=0;i<palabra.length();i++)
		{
			if(palabra[i] == 'i')
			{
				salida = 'N';
			}
		}
			
		cout << salida << endl;
	}
	return 0;
}